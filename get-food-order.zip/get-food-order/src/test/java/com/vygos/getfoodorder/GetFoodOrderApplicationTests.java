package com.vygos.getfoodorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetFoodOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
